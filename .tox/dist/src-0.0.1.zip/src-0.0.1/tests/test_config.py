

def test__Ramesh():
    a=1
    b=1
    assert a==b